package com.gen.pages;

import java.awt.AWTException;
import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.gen.common.CommonUtils;
import com.genworth.utils.GenworthUtils;
import com.tavant.base.DriverFactory;
import com.tavant.kwutils.CustomStep;
import com.tavant.utils.TwfException;

import jxl.read.biff.BiffException;

public class MasterPolicyPage extends CustomStep {

	static WebDriver driver;
	private static final Logger logger = Logger.getLogger(MasterPolicyPage.class);
	GenworthUtils genworthUtils= new GenworthUtils();
	public void checkDropDownInMasterPolicy() throws TwfException, BiffException, IOException, InterruptedException {
		System.out.println("*****************checkDropDownInMasterPolicy**********************");
		driver = DriverFactory.getDriver();
		System.out.println("test : " + step.getDataValue("OrganisationClassification"));
		// Select Org Classification under 'Organization Details' tab
		if (step.getDataValue("OrganisationClassification").equals("Credit Union Service Organization (CUSO)")
				|| step.getDataValue("OrganisationClassification").equals("Mortgage Banker")
				|| step.getDataValue("OrganisationClassification").equals("Mortgage Broker") 
				|| step.getDataValue("OrganisationClassification").equals("Other") //Other
				|| step.getDataValue("OrganisationClassification").equals("Credit Union Service Organization (CUSO)")) {
			System.out.println("Test1");
			if (step.getDataValue("OrganizationEstablishedDateIsFiveYears").equals("Yes")) {
				waitForElement(getElementByUsing("MasterPolicyLessThanFiveYears"), 20);
				System.out.println("Test2");
				getElementByUsing("MasterPolicyLessThanFiveYears").click();
				waitForElement(getElementByUsing("MasterPolicyOrgLessThanFivePopup"), 20);
				getElementByUsing("MasterPolicyOrgLessThanFivePopup").click(); // Click
																				// 'Ok'
																				// on
																				// documents
																				// required
																				// modal
																				// window.
			} else {
				System.out.println("Test3");
				getElementByUsing("MasterPolicyOrgMoreThanFivePopup").click();
				waitForElement(getElementByUsing("MasterPolicyOrgLessThanFivePopup"), 20);
				getElementByUsing("MasterPolicyOrgLessThanFivePopup").click();
			}
		}

		// Select Checkbox for 'Underwrite loans in its name?'. field
		if (step.getDataValue("UnderwritingLoanOwnName").equalsIgnoreCase("Yes")) {
			CommonUtils.ScrollToElement(getElementByUsing("MasterPolicyUnderwritingLoanOwnNameYes"));
			getElementByUsing("MasterPolicyUnderwritingLoanOwnNameYes").click();
		} else {
			CommonUtils.ScrollToElement(getElementByUsing("MasterPolicyUnderwritingLoanOwnNameNo"));
			getElementByUsing("MasterPolicyUnderwritingLoanOwnNameNo").click();
			waitForElement(getElementByUsing("MasterPolicyButtonForUnderwrting"), 30);
			getElementByUsing("MasterPolicyButtonForUnderwrting").click(); // Click
																			// 'Ok'
																			// on
																			// 'additional
																			// Info
																			// may
																			// be
																			// required'
																			// modal
																			// window.
		}

		// Select checkbox for 'Close loans in its name?' field
		if (step.getDataValue("CloseLoanOwn").equalsIgnoreCase("Yes")) {
			CommonUtils.ScrollToElement(getElementByUsing("MasterPolicyCloseLoanYes"));
			getElementByUsing("MasterPolicyCloseLoanYes").click();
		} else {
			CommonUtils.ScrollToElement(getElementByUsing("MasterPolicyCloseLoanNo"));
			getElementByUsing("MasterPolicyCloseLoanNo").click();
			waitForElement(getElementByUsing("MasterPolicyButtonForUnderwrting"), 30);
			getElementByUsing("MasterPolicyButtonForUnderwrting").click(); // Click
																			// 'Ok'
																			// on
																			// 'additional
																			// Info
																			// may
																			// be
																			// required'
																			// modal
																			// window.
		}

	} // End of Method

	public void fillKeyContactsInMasterPolicy() throws Exception {
		System.out.println("*****************fillKeyContactsInMasterPolicy**********************");

		driver = DriverFactory.getDriver();
		waitForPageToLoad();
		Thread.sleep(2000);
		List<WebElement> keyContactsTable = driver.findElements(By.xpath("//*[@formcontrolname='firstName']"));
		int count = keyContactsTable.size();
		// System.out.println("Count is" +count);
		if (count == 1) {
			// System.out.println("Inside 10");
			getElementByUsing("KeyContactsFirstName").sendKeys((step.getDataValue("KeyContactsFirstName")));
			getElementByUsing("KeyContactsLastName").sendKeys(step.getDataValue("KeyContactsLastName"));
			getElementByUsing("KeyContactsTitle").sendKeys(step.getDataValue("KeyContactsTitle"));
			// getElementByUsing("KeyContactsPhone1").sendKeys(step.getDataValue("KeyContactsPhone1"));
			getElementByUsing("KeyContactsEmail").sendKeys(step.getDataValue("KeyContactsEmail"));

			getElementByUsing("AddNewKeyContactContact").click();
			getElementByUsing("ContactTypeDesignation").sendKeys(step.getDataValue("ContactTypeDesignation"));
			getElementByUsing("KeyContactsFirstName1").sendKeys((step.getDataValue("KeyContactsFirstName1")));
			getElementByUsing("KeyContactsLastName1").sendKeys(step.getDataValue("KeyContactsLastName1"));
			getElementByUsing("KeyContactsTitle1").sendKeys(step.getDataValue("KeyContactsTitle1"));
			// getElementByUsing("KeyContactsPhone1").sendKeys(step.getDataValue("KeyContactsPhone1"));
			getElementByUsing("KeyContactsEmail1").sendKeys(step.getDataValue("KeyContactsEmail1"));
			getElementByUsing("MasterPolicyDeleteOptionalContact").click();
		}

		if (count == 2) {
			// System.out.println("Inside 10");

			getElementByUsing("KeyContactsFirstName").sendKeys((step.getDataValue("KeyContactsFirstName")));
			getElementByUsing("KeyContactsLastName").sendKeys(step.getDataValue("KeyContactsLastName"));
			getElementByUsing("KeyContactsTitle").sendKeys(step.getDataValue("KeyContactsTitle"));
			// getElementByUsing("KeyContactsPhone1").sendKeys(step.getDataValue("KeyContactsPhone1"));
			getElementByUsing("KeyContactsEmail").sendKeys(step.getDataValue("KeyContactsEmail"));

			getElementByUsing("KeyContactsFirstName1").sendKeys((step.getDataValue("KeyContactsFirstName1")));
			getElementByUsing("KeyContactsLastName1").sendKeys(step.getDataValue("KeyContactsLastName1"));
			getElementByUsing("KeyContactsTitle1").sendKeys(step.getDataValue("KeyContactsTitle1"));
			// getElementByUsing("KeyContactsPhone1").sendKeys(step.getDataValue("KeyContactsPhone1"));
			getElementByUsing("KeyContactsEmail1").sendKeys(step.getDataValue("KeyContactsEmail1"));

			getElementByUsing("AddNewKeyContactContact").click();
			getElementByUsing("ContactTypeDesignation").sendKeys(step.getDataValue("ContactTypeDesignation"));
			getElementByUsing("KeyContactsFirstName2").sendKeys((step.getDataValue("KeyContactsFirstName2")));
			getElementByUsing("KeyContactsLastName2").sendKeys(step.getDataValue("KeyContactsLastName2"));
			getElementByUsing("KeyContactsTitle2").sendKeys(step.getDataValue("KeyContactsTitle2"));
			// getElementByUsing("KeyContactsPhone2").sendKeys(step.getDataValue("KeyContactsPhone2"));
			getElementByUsing("KeyContactsEmail2").sendKeys(step.getDataValue("KeyContactsEmail2"));
			getElementByUsing("MasterPolicyDeleteOptionalContact").click();
		} else if (count == 3) {
			// System.out.println("Inside 15");
			getElementByUsing("KeyContactsFirstName").sendKeys((step.getDataValue("KeyContactsFirstName")));
			getElementByUsing("KeyContactsLastName").sendKeys(step.getDataValue("KeyContactsLastName"));
			getElementByUsing("KeyContactsTitle").sendKeys(step.getDataValue("KeyContactsTitle"));
			// getElementByUsing("KeyContactsPhone1").sendKeys(step.getDataValue("KeyContactsPhone1"));
			getElementByUsing("KeyContactsEmail").sendKeys(step.getDataValue("KeyContactsEmail"));

			getElementByUsing("KeyContactsFirstName1").sendKeys((step.getDataValue("KeyContactsFirstName1")));
			getElementByUsing("KeyContactsLastName1").sendKeys(step.getDataValue("KeyContactsLastName1"));
			getElementByUsing("KeyContactsTitle1").sendKeys(step.getDataValue("KeyContactsTitle1"));
			// getElementByUsing("KeyContactsPhone1").sendKeys(step.getDataValue("KeyContactsPhone1"));
			getElementByUsing("KeyContactsEmail1").sendKeys(step.getDataValue("KeyContactsEmail1"));
			getElementByUsing("KeyContactsFirstName2").sendKeys((step.getDataValue("KeyContactsFirstName2")));
			getElementByUsing("KeyContactsLastName2").sendKeys(step.getDataValue("KeyContactsLastName2"));
			getElementByUsing("KeyContactsTitle2").sendKeys(step.getDataValue("KeyContactsTitle2"));
			// getElementByUsing("KeyContactsPhone2").sendKeys(step.getDataValue("KeyContactsPhone2"));
			getElementByUsing("KeyContactsEmail2").sendKeys(step.getDataValue("KeyContactsEmail2"));

			getElementByUsing("AddNewKeyContactContact").click();
			getElementByUsing("ContactTypeDesignation").sendKeys(step.getDataValue("ContactTypeDesignation"));
			getElementByUsing("KeyContactsFirstName3").sendKeys((step.getDataValue("KeyContactsFirstName3")));
			getElementByUsing("KeyContactsLastName3").sendKeys(step.getDataValue("KeyContactsLastName3"));
			getElementByUsing("KeyContactsTitle3").sendKeys(step.getDataValue("KeyContactsTitle3"));
			// getElementByUsing("KeyContactsPhone3").sendKeys(step.getDataValue("KeyContactsPhone3"));
			getElementByUsing("KeyContactsEmail3").sendKeys(step.getDataValue("KeyContactsEmail3"));
			getElementByUsing("MasterPolicyDeleteOptionalContact").click();
		} else if (count == 4) {
			getElementByUsing("KeyContactsFirstName").sendKeys((step.getDataValue("KeyContactsFirstName")));
			getElementByUsing("KeyContactsLastName").sendKeys(step.getDataValue("KeyContactsLastName"));
			getElementByUsing("KeyContactsTitle").sendKeys(step.getDataValue("KeyContactsTitle"));
			// getElementByUsing("KeyContactsPhone1").sendKeys(step.getDataValue("KeyContactsPhone1"));
			getElementByUsing("KeyContactsEmail").sendKeys(step.getDataValue("KeyContactsEmail"));

			// System.out.println("Inside else");
			getElementByUsing("KeyContactsFirstName1").sendKeys((step.getDataValue("KeyContactsFirstName1")));
			getElementByUsing("KeyContactsLastName1").sendKeys(step.getDataValue("KeyContactsLastName1"));
			getElementByUsing("KeyContactsTitle1").sendKeys(step.getDataValue("KeyContactsTitle1"));
			// getElementByUsing("KeyContactsPhone1").sendKeys(step.getDataValue("KeyContactsPhone1"));
			getElementByUsing("KeyContactsEmail1").sendKeys(step.getDataValue("KeyContactsEmail1"));
			getElementByUsing("KeyContactsFirstName2").sendKeys((step.getDataValue("KeyContactsFirstName2")));
			getElementByUsing("KeyContactsLastName2").sendKeys(step.getDataValue("KeyContactsLastName2"));
			getElementByUsing("KeyContactsTitle2").sendKeys(step.getDataValue("KeyContactsTitle2"));
			// getElementByUsing("KeyContactsPhone2").sendKeys(step.getDataValue("KeyContactsPhone2"));
			getElementByUsing("KeyContactsEmail2").sendKeys(step.getDataValue("KeyContactsEmail2"));
			getElementByUsing("KeyContactsFirstName3").sendKeys((step.getDataValue("KeyContactsFirstName3")));
			getElementByUsing("KeyContactsLastName3").sendKeys(step.getDataValue("KeyContactsLastName3"));
			getElementByUsing("KeyContactsTitle3").sendKeys(step.getDataValue("KeyContactsTitle3"));
			// getElementByUsing("KeyContactsPhone3").sendKeys(step.getDataValue("KeyContactsPhone3"));
			getElementByUsing("KeyContactsEmail3").sendKeys(step.getDataValue("KeyContactsEmail3"));

			getElementByUsing("AddNewKeyContactContact").click();
			getElementByUsing("ContactTypeDesignation").sendKeys(step.getDataValue("ContactTypeDesignation"));
			getElementByUsing("KeyContactsFirstName4").sendKeys((step.getDataValue("KeyContactsFirstName4")));
			getElementByUsing("KeyContactsLastName4").sendKeys(step.getDataValue("KeyContactsLastName4"));
			getElementByUsing("KeyContactsTitle4").sendKeys(step.getDataValue("KeyContactsTitle4"));
			// getElementByUsing("KeyContactsPhone3").sendKeys(step.getDataValue("KeyContactsPhone3"));
			getElementByUsing("KeyContactsEmail4").sendKeys(step.getDataValue("KeyContactsEmail4"));
			getElementByUsing("MasterPolicyDeleteOptionalContact").click();
		}

	} // End of Method

	public void fillGovtRegistryInMasterPolicy() throws TwfException {
		try {
			waitForPageToLoad();

			if (getElementByUsing("FannieMae").isDisplayed()) {
				getElementByUsing("FannieMae").click();
				getElementByUsing("FannieMaeNumber").sendKeys(step.getDataValue("FannieMaeNumber"));
				getElementByUsing("FHA").click();
				getElementByUsing("FHANumber").sendKeys(step.getDataValue("FHANumber"));
				getElementByUsing("FreddieMac").click();
				getElementByUsing("FreddieMacNumber").sendKeys(step.getDataValue("FreddieMacNumber"));
				getElementByUsing("VA").click();
				getElementByUsing("VANumber").sendKeys(step.getDataValue("VANumber"));
				if (step.getDataValue("None").equalsIgnoreCase("none")) {
					getElementByUsing("None").click();
				}

			} else {
				getElementByUsing("FDIC").click();
				getElementByUsing("FDICNumber").sendKeys(step.getDataValue("FDICNumber"));
				getElementByUsing("MasterPolicyOtherOption").click();
				getElementByUsing("OtherTBNumber").sendKeys(step.getDataValue("OtherTBNumber"));
				getElementByUsing("OtherTBName").sendKeys(step.getDataValue("OtherTBName"));

			}

			boolean partnershiptype = (step.getDataValue("PartnershipTypeDropdown").equals("Servicing Only"));
			System.out.println(
					"PartnershipStype is" + partnershiptype + "test :" + step.getDataValue("PartnershipTypeDropdown"));

			if (partnershiptype == false) {
				CommonUtils.ScrollToElement(getElementByUsing("MasterPolicyFraudAccuracy"));
				getElementByUsing("MasterPolicyFraudAccuracy").click();
				CommonUtils.ScrollToElement(getElementByUsing("MasterPolicyFraudDocument"));
				getElementByUsing("MasterPolicyFraudDocument").click();
				CommonUtils.ScrollToElement(getElementByUsing("MasterPolicyFraudQuality"));
				getElementByUsing("MasterPolicyFraudQuality").click();
				CommonUtils.ScrollToElement(getElementByUsing("MasterPolicyFraudApproval"));
				getElementByUsing("MasterPolicyFraudApproval").click();
				CommonUtils.ScrollToElement(getElementByUsing("MasterPolicyFraudAppraisal"));
				getElementByUsing("MasterPolicyFraudAppraisal").click();
				CommonUtils.ScrollToElement(getElementByUsing("MasterPolicyZeroToFive"));
				getElementByUsing("MasterPolicyZeroToFive").click();
				CommonUtils.ScrollToElement(getElementByUsing("MasterPolicyUnderwriter"));
				getElementByUsing("MasterPolicyUnderwriter").click();
			}

		} catch (Exception e) {

		}
	}

	public void orgSuspendedCheckboxes() throws TwfException, BiffException, IOException, InterruptedException {
		driver = DriverFactory.getDriver();

		waitForElement(getElementByUsing("SuspendFannieMae"), 7000);
		CommonUtils.ScrollToElement(getElementByUsing("SuspendFannieMae"));
		click(getElementByUsing("SuspendFannieMae"));

		waitForElement(getElementByUsing("SuspendFHA"), 7000);
		CommonUtils.ScrollToElement(getElementByUsing("SuspendFHA"));
		click(getElementByUsing("SuspendFHA"));

		waitForElement(getElementByUsing("SuspendPrivateMortgageInsurer"), 7000);
		CommonUtils.ScrollToElement(getElementByUsing("SuspendPrivateMortgageInsurer"));
		click(getElementByUsing("SuspendPrivateMortgageInsurer"));

		waitForElement(getElementByUsing("SuspendVA"), 7000);
		CommonUtils.ScrollToElement(getElementByUsing("SuspendVA"));
		click(getElementByUsing("SuspendVA"));

		waitForElement(getElementByUsing("SuspendRegulatoryAuthority"), 7000);
		CommonUtils.ScrollToElement(getElementByUsing("SuspendRegulatoryAuthority"));
		click(getElementByUsing("SuspendRegulatoryAuthority"));

		waitForElement(getElementByUsing("SuspendReason"), 7000);
		CommonUtils.ScrollToElement(getElementByUsing("SuspendReason"));
		type(getElementByUsing("SuspendReason"), step.getDataValue("SuspendReason"));

		if (step.getDataValue("None").equalsIgnoreCase("none")) {

			waitForElement(getElementByUsing("SuspendNone"), 7000);
			CommonUtils.ScrollToElement(getElementByUsing("SuspendNone"));
			click(getElementByUsing("SuspendNone"));
		}
	}

	public void fileUpload_BasePage() throws TwfException, InterruptedException, IOException, BiffException {

		driver = DriverFactory.getDriver();
		String browesername = DriverFactory.getBrowserAsString();
		System.out.println(browesername);
		System.out.println("Inside file upload");
		String autoitscriptpath = "";
		String workingDir = System.getProperty("user.dir");
		String a = step.getDataValue("FileUploadPath");
		if (browesername.equals("firefox")) {
			System.out.println("Inside firefox");
			autoitscriptpath = workingDir + "\\" + "Files\\FileUploadInFireFox.exe";
		} else if (browesername.equals("iexplore")) {
			System.out.println("Inside iexplore");
			autoitscriptpath = workingDir + "\\" + "Files\\FileUploadInIExplorer.exe";
		} else {
			System.out.println("Inside chrome");
			autoitscriptpath = workingDir + "\\" + "Files\\FileUploadInChrome.exe";
		}
		System.out.println(autoitscriptpath);
		String filepath = workingDir + "\\Files\\NICClaimForm.pdf";
		// driver.get(filepath);
		// Added a wait to make you notice the difference.
		Thread.sleep(1000);

		System.out.println(filepath);
		Runtime.getRuntime().exec(" " + autoitscriptpath + " \"" + filepath + "\"");

		waitUntilDefaultTimeout();

	}

	
	public void uploadFile(String fileName) throws TwfException, BiffException, IOException, InterruptedException
	{
		logger.debug("Inside uploadFile");
		driver=DriverFactory.getDriver();
		String path = System.getProperty("user.dir");
		path = path + "\\src\\test\\resources\\Files\\"+fileName;	//NICClaimForm.pdf"
		WebElement addFileBtn = getElementByUsing("uploadFile");
		addFileBtn.sendKeys(path);
		Thread.currentThread().sleep(1000);
		genworthUtils.waitforLoading("");
		logger.debug("Finished uploadFile");
	}
	
	
	public void addingNotesInMasterPolicy()
			throws AWTException, TwfException, BiffException, IOException, InterruptedException {
		
		genworthUtils.waitforLoading("");
		genworthUtils.waitforLoading("");
		waitForElement(getElementByUsing("MasterPolicySuccessMessageVerify"), 60);
		
		CommonUtils.ScrollToElement(getElementByUsing("MasterPolicySuccessMessageVerify"));
		WebElement element = getElementByUsing("MasterPolicySuccessMessageVerify");
		String elementText = element.getText();
		// System.out.println("elementText: -"+elementText);

		if (!(elementText.contains(step.getDataValue("VerifySuccessMasterPolicy")))) {
			addExceptionToReport("Actual value does not match with Expected value ", String.valueOf(elementText),
					String.valueOf(step.getDataValue("VerifySuccessMasterPolicy")));
		}
		
		if (step.getDataValue("OrganizationEstablishedDateIsFiveYears").equals("Yes") || step.getDataValue("OrganizationEstablishedDateIsFiveYears").equals("No")) {
			
			CommonUtils.ScrollToElement(getElementByUsing("AddFilesButton"));
			waitForElement(getElementByUsing("AddFilesButton"), 5000);
			//getElementByUsing("AddFilesButton").click();
			//fileUpload_BasePage();
			uploadFile("NICClaimForm.pdf"); 
			if(step.getDataValue("OrganizationEstablishedDateIsFiveYears").equals("Yes"))
			uploadFile("NICCClaimduplicate.pdf");//NICCClaimduplicate
			getElementByUsing("MasterPolicyNotes").sendKeys(step.getDataValue("MasterPolicyNotes"));
			getElementByUsing("MasterPolicyNotesSubmit").click();
			Thread.currentThread().sleep(1000);
			genworthUtils.waitforLoading("");
			Thread.currentThread().sleep(1000);
			genworthUtils.waitforLoading("");
			genworthUtils.waitforLoading("");
			
			
			
			if (!(getElementByUsing("submitSuccessMsg").getText().contains(step.getDataValue("VerifySuccessMasterPolicy")))) {
				addExceptionToReport("Actual value does not match with Expected value ", getElementByUsing("submitSuccessMsg").getText(),
						String.valueOf(step.getDataValue("VerifySuccessMasterPolicy")));
			}
			
			
		}
	}

	public void dropdownfillOrganisationInfo() throws TwfException, BiffException, IOException, InterruptedException {
		driver = DriverFactory.getDriver();
		if (step.getDataValue("OrganisationClassification").equals("Credit Union Service Organization (CUSO)")
				|| step.getDataValue("OrganisationClassification").equals("Mortgage Banker")
				|| step.getDataValue("OrganisationClassification").equals("Mortgage Broker")
				|| step.getDataValue("OrganisationClassification").equals("Credit Union Service Organization (CUSO)")) {
			Thread.sleep(2000);
			if (step.getDataValue("OrganizationEstablishedDateIsFiveYears").equals("Yes")) {
				System.out.println("Inside OrganizationEstablishedDateIsFiveYears");
				getElementByUsing("MasterPolicyLessThanFiveYears").click();
				Thread.sleep(2000);
				getElementByUsing("MasterPolicyButtonForUnderwrting").click();

			} else {
				System.out.println("Inside OrganizationEstablishedDate MORE THAN FiveYears");
				getElementByUsing("MasterPolicyOrgMoreThanFiveInBasicInfo").click();
				Thread.sleep(2000);
				getElementByUsing("MasterPolicyButtonForUnderwrting").click();
			}
		}

	}

	@Override
	public void checkPage() {
		// TODO Auto-generated method stub

	}

}
