package com.gen.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.tavant.base.DriverFactory;
import com.tavant.kwutils.CustomStep;
import com.tavant.utils.TwfException;

import jxl.read.biff.BiffException;

public class CS_Agreement extends CustomStep {
	static WebDriver driver;
	
	public void AngularUIDropDown() throws InterruptedException, TwfException,
	 BiffException, IOException {
		 driver = DriverFactory.getDriver();
		 String[] z = step.getValue().split(",");
		 getElementByUsing(z[0]).click();
		 //driver.findElement(By.xpath(".//*[@class="ui-select-choices-row-inner" +  "" + "]/span[text()='ALABAMA']")");
		 Select mpDropDown = new Select(driver.findElement(By.xpath("//select[@formcontrolname='masterPolicy']")));
		 mpDropDown.selectByVisibleText(step.getDataValue(z[1]));
	 } 
	
	
	
	@Override
	public void checkPage() {
		// TODO Auto-generated method stub
		
	}

}
