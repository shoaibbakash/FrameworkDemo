package com.gen.common;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.http.nio.conn.ssl.SSLLayeringStrategy;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.tavant.base.DriverFactory;
import com.tavant.kwutils.CustomStep;
import com.tavant.kwutils.KWVariables;
import com.tavant.utils.TwfException;

import jxl.read.biff.BiffException;

public class CommonUtils extends CustomStep {

	static WebDriver driver;

	public void clickUsingJSinFire() throws BiffException, IOException, TwfException, InterruptedException {
		WebDriver driver = DriverFactory.getDriver();
		String element = step.getValue();
		WebElement ele = getElementByUsing(element);
		System.out.println("element:" + element);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		// js.executeScript("arguments[0].scrollIntoView(false);", ele);
		js.executeScript("arguments[0].click();", ele);
		System.out.println("Clicked");

	}

	public void ScrollToElement() throws BiffException, IOException, TwfException, InterruptedException {
		WebDriver driver = DriverFactory.getDriver();
		String a = step.getValue();
		WebElement ab = getElementByUsing(a);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		waitUntilDefaultTimeout();
		System.out.println("Moving to Element:" + a);
		js.executeScript("arguments[0].scrollIntoView(true);", ab);
	}

	public void waitForElements() throws TwfException, BiffException, IOException {
		driver = DriverFactory.getDriver();
		String t = step.getValue();
		System.out.println("Waiting for element for 3 mins" + t);
		waitForElement(getElementByUsing(t), 180);
	}

	public void zipCodeSelectionFromThePopUp()
			throws TwfException, BiffException, IOException, InterruptedException, InvalidFormatException {
		System.out.println("********zipCodeSelectionFromThePopUp*******");
		driver = DriverFactory.getDriver();
		String args[] = KWVariables.getVariables().get(step.getValue()).split(",");
		clearAndSendKeys(getElementByUsing(args[0]), step.getDataValue(args[0]));
		Actions act = new Actions(driver);
		act.sendKeys(Keys.TAB).build().perform();
		System.out.println("Select ZIP:");
		// getElementByUsing("Harpzip").sendKeys(Keys.TAB);
		// Thread.sleep(2000);
		DriverFactory.getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		if (DriverFactory.getDriver().findElements(By.xpath(args[1])).size() != 0) {
			System.out.println("Inside condition");
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			// waitForElement(getElementByUsing(args[2]), 10000);
			Thread.sleep(2000);
			ScrollToElement(getElementByUsing(args[2]));
			Thread.sleep(2000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", getElementByUsing(args[2]));
			Thread.sleep(2000);
			getElementByUsing(args[3]).click();
			DriverFactory.getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		}
	} // End of method

	public static void ScrollToElement(WebElement ele)
			throws BiffException, IOException, TwfException, InterruptedException {
		driver = DriverFactory.getDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Thread.sleep(3000);
		js.executeScript("arguments[0].scrollIntoView(false);", ele);
	}

	public void verifyTextOfElements() throws BiffException, IOException, TwfException, InterruptedException {
		driver = DriverFactory.getDriver();
		String[] t = step.getValue().split(",", 2);
		WebElement actual = getElementByUsing(t[0]);
		String actualResult = actual.getText();
		System.out.println("Actual Result --> " + actualResult);
		String expected = step.getDataValue(t[1]);
		System.out.println("Expected --> " + expected);
		// waitUntilDefaultTimeout();
		if (!(actualResult.contains(expected))) {
			addExceptionToReport("Actual value does not match with Expected value ", String.valueOf(actualResult),
					String.valueOf(expected));
		}
	}

	
	
	public void customType() throws InterruptedException, IOException, TwfException, BiffException
	{
		driver = DriverFactory.getDriver();
		WebElement element=null;
		try{
			element = getElementByUsing(step.getValue());
		}
		catch (Exception e)
		{
			System.out.println("element not found");
			e.printStackTrace();
		}
		
		if(element!=null)
		{
			element.clear();
			element.sendKeys(step.getDataValue(step.getValue())+Keys.TAB);
			System.out.println("cusType success...");
		}
		
		
		
	}
	
	
	public void waitUntilElementFound() throws InterruptedException, IOException, TwfException, BiffException

	{
		System.out.println("********waitUntilElementFound*******");
		WebDriver driver = DriverFactory.getDriver();
		WebDriverWait wait = new WebDriverWait(driver, 120);
		String a = step.getValue();
		System.out.println("Waiting for Element :"+a);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(a)));
		System.out.print("Element is now visible");
	}
	
	public void debugWait() throws InterruptedException, IOException, TwfException, BiffException

	{
		System.out.println("inside debugWait");
		WebDriver driver = DriverFactory.getDriver();
		
		System.out.print("finished debugWait");
	}
	
	

	@Override
	public void checkPage() {
		// TODO Auto-generated method stub

	}

}
