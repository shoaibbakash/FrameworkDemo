package com.genworth.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.joda.time.Chronology;

import com.tavant.base.WebPage;

public class ExcelUtils extends WebPage {

	
	public final String CertiLinkCalculatorSheet = "Calculator_CertiLink.xlsx";
	private static final Logger logger = Logger.getLogger(ExcelUtils.class);
	
	public void readDataFromExcel(String docName) throws IOException {
		String path;
		FileInputStream fis;
		XSSFWorkbook workbook;
		XSSFSheet sheet = null;
		XSSFRow row = null;
		XSSFCell cell = null;

		// path = System.getProperty("user.dir")+"\\resources\\Book1.xlsx";
		path = System.getProperty("user.dir");
		path = path + "\\src\\test\\resources\\Excel\\" + docName;																					// "D:\\test.xlsx";
		fis = new FileInputStream(path);
		workbook = new XSSFWorkbook(fis);
		sheet = workbook.getSheetAt(0);

		int index = workbook.getSheetIndex("Sheet1");
		sheet = workbook.getSheetAt(index);
		int rownumber = sheet.getLastRowNum() + 1;

		for (int i = 1; i < rownumber; i++) {
			row = sheet.getRow(i);
			int colnumber = row.getLastCellNum();
			for (int j = 0; j < colnumber; j++) {
				cell = row.getCell(j);
				if (cell != null)
					System.out.print(cell.getStringCellValue() + " ");
			}
			System.out.println("\n");
		}

	}
	
	
	
	
	public String getRefundAmountFromCalculationsExcel(String certiNumber, String docName) throws IOException
	{
		String path;
		FileInputStream fis;
		XSSFWorkbook workbook;
		XSSFSheet sheet = null;
		XSSFRow row = null;
		XSSFCell cell = null;
		
		String refundAmt=null;

		// path = System.getProperty("user.dir")+"\\resources\\Book1.xlsx";
		path = System.getProperty("user.dir");
		path = path + "\\src\\test\\resources\\Excel\\" + docName;																					// "D:\\test.xlsx";
		fis = new FileInputStream(path);
		workbook = new XSSFWorkbook(fis);
		//sheet = workbook.getSheetAt(0);

		int index = workbook.getSheetIndex("Calc");
		sheet = workbook.getSheetAt(index);
		int rownumber = sheet.getLastRowNum() + 1;

		DataFormatter dataFormatter = new DataFormatter();
        //String value = dataFormatter.formatCellValue(cell);
		for (int i = 1; i < rownumber; i++) {
			row = sheet.getRow(i);
			cell = row.getCell(1);
			
				if (cell != null)
				{
					
					//if(cell.getStringCellValue().toString().equalsIgnoreCase(certiNumber))
					
					if(dataFormatter.formatCellValue(cell).equalsIgnoreCase(certiNumber))
					{
						cell = row.getCell(28);
						//refundAmt = cell.getStringCellValue();
						
						refundAmt =dataFormatter.formatCellValue(cell);
						break;
					}
					
					
					
			}
			
		}
		
		return refundAmt;
	}
	
	
	
	public void updateEffectiveDate(Map<String, String> data) throws IOException, ParseException
	{
		logger.debug("Inside updateEffectiveDate");
		String path;
		FileInputStream fis;
		XSSFWorkbook workbook;
		XSSFSheet sheet = null;
		XSSFRow row = null;
		XSSFCell cell = null;
		
		
		  SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
	        String dateInString = data.get("CancellationEfectiveDate");
	        Date date = formatter.parse(dateInString);
	        
		path = System.getProperty("user.dir");
		path = path + "\\src\\test\\resources\\Excel\\"+CertiLinkCalculatorSheet;																					// "D:\\test.xlsx";
		fis = new FileInputStream(path);
		workbook = new XSSFWorkbook(fis);
		//sheet = workbook.getSheetAt(0);

		sheet = workbook.getSheetAt(0);
		int rownumber = sheet.getLastRowNum() + 1;

		DataFormatter dataFormatter = new DataFormatter();
        //String value = dataFormatter.formatCellValue(cell);
		for (int i = 0; i < rownumber; i=i+5) {
			row = sheet.getRow(i);
			cell = row.getCell(0);
			
				if (cell != null)
				{
					if(dataFormatter.formatCellValue(cell).contains(data.get("CertiNum")))
					{
						logger.debug("found certi"+data.get("CertiNum"));
						XSSFRow newRow = null;
						XSSFCell newCell = null;
						XSSFRow formulaRow = null;
						XSSFCell formulaCell = null;
						
						LocalDate effDate = LocalDate.of(Integer.parseInt(dateInString.split("/")[2]), Integer.parseInt(dateInString.split("/")[0]), Integer.parseInt(dateInString.split("/")[1]));
						String days = String.valueOf(effDate.lengthOfMonth());
						
						
						formulaRow = sheet.getRow(i+3);
						formulaCell = formulaRow.getCell(2);
						
						String formula = formulaCell.getCellFormula();
						String newFormula = formula;
						
						if(!(formula.contains(days)) && formula.contains("31"))
						{
						newFormula=	newFormula.replace("31", days);
						formulaCell.setCellFormula(newFormula);
						logger.debug("updated days "+days+" in formula.....!!");
						}
						else if(!(formula.contains(days)) && formula.contains("30"))
						{
						newFormula= newFormula.replace("30", days);
						formulaCell.setCellFormula(newFormula);
						logger.debug("updated days "+days+" in formula.....!!");
						}
						
						else if(!(formula.contains(days)) && formula.contains("28"))
						{
						newFormula= newFormula.replace("28", days);
						formulaCell.setCellFormula(newFormula);
						logger.debug("updated days "+days+" in formula.....!!");
						}
						
						else if(!(formula.contains(days)) && formula.contains("29"))
						{
						newFormula= newFormula.replace("29", days);
						formulaCell.setCellFormula(newFormula);
						logger.debug("updated days "+days+" in formula.....!!");
						}
						
						else
							logger.debug("formula already upto date!!");
						
						newRow = sheet.getRow(i+2);
						newCell = newRow.getCell(1);
						//XSSFCellStyle cs=	newCell.getCellStyle();
						//newCell.setCellValue("");
						newCell.setCellValue(date);
						logger.debug("updated effective date......!!");
						//newCell.setCellValue("8/8/2019");
						//newCell.setCellStyle(cs);
						
						
						
						break;
					}
					
					if(dataFormatter.formatCellValue(cell).contains("Z Monthly"))
					{
						i=i+1;
					}
					
			}
			
		}
		
		
		XSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);
		fis.close();
		
		FileOutputStream outFile =new FileOutputStream(path);
		workbook.write(outFile);
		outFile.close();
		logger.debug("finished updateEffectiveDate");
	}
	
	
	public String getPremiumDue(String certiNumber) throws ParseException, IOException
	{
		logger.debug("Inside getPremiumDue");
		String path;
		FileInputStream fis;
		XSSFWorkbook workbook;
		XSSFSheet sheet = null;
		XSSFRow row = null;
		XSSFCell cell = null;
		String premiumDue =null;
		
		path = System.getProperty("user.dir");
		path = path + "\\src\\test\\resources\\Excel\\"+CertiLinkCalculatorSheet;																					
		fis = new FileInputStream(path);
		workbook = new XSSFWorkbook(fis);
		//sheet = workbook.getSheetAt(0);

		sheet = workbook.getSheetAt(0);
		int rownumber = sheet.getLastRowNum() + 1;

		DataFormatter dataFormatter = new DataFormatter();
        //String value = dataFormatter.formatCellValue(cell);
		for (int i = 0; i < rownumber; i=i+5) {
			row = sheet.getRow(i);
			cell = row.getCell(0);
			
				if (cell != null)
				{
					
					if(dataFormatter.formatCellValue(cell).contains(certiNumber))
					{
						logger.debug("found certiNum: "+certiNumber);
						XSSFRow newRow = null;
						XSSFCell newCell = null;
						newRow = sheet.getRow(i+4);
						newCell = newRow.getCell(2);
						DecimalFormat decimalFormat = new DecimalFormat("##.00");
						float value =Float.parseFloat(newCell.getRawValue());
						premiumDue = decimalFormat.format(Math.abs(value));
						break;
					}
					if(dataFormatter.formatCellValue(cell).contains("Z Monthly"))
					{
						i=i+1;
					}
			    }
		}
		
		
		//XSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);
		fis.close();
		logger.debug("finished getPremiumDue");
		return premiumDue;
	}
	
	
	
	
	public String getStubValue(String certiNumber) throws ParseException, IOException
	{
		logger.debug("Inside getStubValue");
		String path;
		FileInputStream fis;
		XSSFWorkbook workbook;
		XSSFSheet sheet = null;
		XSSFRow row = null;
		XSSFCell cell = null;
		String stubValue =null;
		boolean hasStubValue=false;
		
		path = System.getProperty("user.dir");
		path = path + "\\src\\test\\resources\\Excel\\"+CertiLinkCalculatorSheet;																					
		fis = new FileInputStream(path);
		workbook = new XSSFWorkbook(fis);
		//sheet = workbook.getSheetAt(0);

		sheet = workbook.getSheetAt(0);
		int rownumber = sheet.getLastRowNum() + 1;

		DataFormatter dataFormatter = new DataFormatter();
        //String value = dataFormatter.formatCellValue(cell);
		for (int i = 0; i < rownumber; i=i+5) {
			row = sheet.getRow(i);
			cell = row.getCell(0);
			
				if (cell != null)
				{
					if(dataFormatter.formatCellValue(cell).contains(certiNumber) && dataFormatter.formatCellValue(cell).contains("Z Monthly"))
					{
						logger.debug("found certiNum"+certiNumber);
						hasStubValue=true;
						XSSFRow newRow = null;
						XSSFCell newCell = null;
						newRow = sheet.getRow(i+5);
						newCell = newRow.getCell(2);
						String stub = dataFormatter.formatCellValue(newCell).trim().replaceAll("[^0-9?!\\.]", "");
						DecimalFormat decimalFormat = new DecimalFormat("##.00");
						float value =Float.parseFloat(stub);
						stubValue = decimalFormat.format(value);
						break;
					}
					if(dataFormatter.formatCellValue(cell).contains("Z Monthly"))
					{
						i=i+1;
					}
			    }
		}
		
		
		//XSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);
		fis.close();
		logger.debug("finished getStubValue");
		
		if(hasStubValue)
		return stubValue;
		else
			return null;
	}
	
	
	
	
public String getExportedBulkFileName() throws FileNotFoundException, IOException
{
	logger.debug("inside getExportedBulkFileName ");
	Properties prop = new Properties();
	prop.load(new FileInputStream("src/test/resources/user.properties"));
	File file = new File(prop.getProperty("defaultDownloadPath")); //Change this to the directory you want to search in.

	String fileName=null;
int count=0;
	   if( file.exists() && file.isDirectory() )
	   {
	       //String[] files = file.list(); //get the files in String format.
	     while(count<file.listFiles().length)
	     {
	    	  String fname= file.listFiles()[count].getName();
	    	  if(fname.contains("Bulk Cancellation_"))
	    	  {
	    	  fileName=file.listFiles()[count].getName();
	    	  break;
	    	  }
	    	  count++;
	      }
	   }
	   logger.debug("File name: "+fileName);
	   logger.debug("finished getExportedBulkFileName ");
return fileName;
	
}

public void deleteExistingExportedBulkFile()
{
	logger.debug("inside deleteExistingExportedBulkFile ");
	File file = new File("C:/Users/502004745/Downloads"); //Change this to the directory you want to search in.

	   if( file.exists() && file.isDirectory() )
	   {
	       //String[] files = file.list(); //get the files in String format.
		   for (File f : file.listFiles()) 
		   {
			   
			   String fname= f.getName();
			   if(fname.contains("Bulk Cancellation_"))
		    	  {
			    		  logger.debug("File found: "+fname );
			    		  f.delete();
			    		  logger.debug("Deleted file: "+fname );
		    	  }
		   }
		   
	   }

	   logger.debug("Finished deleteExistingExportedBulkFile");
}


public float getRefundAllValue(String fileName) throws ParseException, IOException
{
	logger.debug("Inside getPremiumAfterDefaultRefundValue");
	String path;
	float sum=0;
	  
    path = System.getProperty("user.dir");
	path = path + "\\src\\test\\resources\\"+fileName;
	FileReader fileReader = new FileReader(path);
	
	
    BufferedReader bufferedReader = new BufferedReader(fileReader);
    String line = null;
          
    while ((line = bufferedReader.readLine()) != null) {
           if (line.length() > 12 && line.length() > 1 && line.length() != 801) {
                 String accTyp = line.split(",")[5].replace((char) 0, ' ').replace(" ", "").trim();
                 String recTyp = line.split(",")[6].replace((char) 0, ' ').replace(" ", "").trim();
                 String txnTyp = line.split(",")[7].replace((char) 0, ' ').replace(" ", "").trim();
                 String refundAmt = line.split(",")[10].replace((char) 0, ' ').replace(" ", "").trim();
                 
			
		if(accTyp.equalsIgnoreCase("5101") || accTyp.equalsIgnoreCase("8381") || accTyp.equalsIgnoreCase("5117"))
			{
				if(recTyp.equalsIgnoreCase("CR") || recTyp.equalsIgnoreCase("GJ"))
				{
					if(txnTyp.equalsIgnoreCase("RC") || txnTyp.equalsIgnoreCase("PT") || txnTyp.equalsIgnoreCase("CC"))
					{
						sum = sum+ Float.parseFloat(refundAmt);
					}
				}
			}
				
			
		}
           
           }
           
           	
				
    		bufferedReader.close();	
		
			logger.debug("sum"+sum);
			logger.debug("finished getRefundAllValue");
			return sum;
			
		
	}


public float getPremiumAfterDefaultRefundValue(String fromDate,String toDate,String fileName) throws ParseException, IOException
{
	logger.debug("Inside getPremiumAfterDefaultRefundValue");
	String path;
	float sum=0;
	
	 SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        String dateInString1 = fromDate;
        String dateInString2 = toDate;
        
        Date dateFrom = formatter.parse(dateInString1);
        Date dateTo = formatter.parse(dateInString2);
        
	path = System.getProperty("user.dir");
	path = path + "\\src\\test\\resources\\"+fileName;
	FileReader fileReader = new FileReader(path);
	
	
    BufferedReader bufferedReader = new BufferedReader(fileReader);
    String line = null;
          
    while ((line = bufferedReader.readLine()) != null) {
           if (line.length() > 12 && line.length() > 1 && line.length() != 801) {
                 String date = line.split(",")[3].replace((char) 0, ' ').replace(" ", "").trim();
                 String accTyp = line.split(",")[5].replace((char) 0, ' ').replace(" ", "").trim();
                 String recTyp = line.split(",")[6].replace((char) 0, ' ').replace(" ", "").trim();
                 String txnTyp = line.split(",")[7].replace((char) 0, ' ').replace(" ", "").trim();
                 String refundAmt = line.split(",")[10].replace((char) 0, ' ').replace(" ", "").trim();
                 
				
		 Date dateGiven = formatter.parse(date);
		
		
		if(dateGiven.compareTo(dateFrom)>=0 && dateGiven.compareTo(dateTo)<=0)
		{
			if(accTyp.equalsIgnoreCase("5101"))
			{
				if(recTyp.equalsIgnoreCase("CR") || recTyp.equalsIgnoreCase("GJ"))
				{
					if(txnTyp.equalsIgnoreCase("RC") || txnTyp.equalsIgnoreCase("CC"))
					{
						sum = sum+ Float.parseFloat(refundAmt);
					}
				}
			}
				
			
		}
           
           }
           
           }	
				
    		bufferedReader.close();	
		
			logger.debug("sum"+sum);
			logger.debug("finished getPremiumAfterDefaultRefundValue");
			return sum;
			
		
	}


	@Override
	public void checkPage() {
		// TODO Auto-generated method stub
		
	}
}