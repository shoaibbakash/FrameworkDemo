package com.genworth.utils;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;

import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;


public class DebugTest {
public void sendXMLPost() throws IOException
{
	
	Scanner inp = new Scanner(new FileReader("D:\\QuoteRequest.xml"));
	
	StringBuilder sb = new StringBuilder();
	while(inp.hasNext()) {
	    sb.append(inp.next());
	}
	inp.close();
	String outString = sb.toString();
	String XMLSRequest = outString;
		
	//String USER_AGENT = "Mozilla/5.0";
	String url = "http://stg-webservices.flexconnect.genworth.com/ndc-mortgageinsurance/PostRequest.aspx";
	 
	RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(30 * 1000).build();

    HttpClient client = HttpClientBuilder.create().setDefaultRequestConfig(requestConfig).build();
    HttpPost postRequest = new HttpPost(url);

    StringEntity params =new StringEntity(XMLSRequest);

    params.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/xml"));
    postRequest.addHeader(HTTP.CONTENT_TYPE, "application/xml");
    //postRequest.setHeader("User-Agent", "Mozilla");
    postRequest.setEntity(params);
    

    HttpResponse response = client.execute(postRequest);
    

    
    System.out.println("\nSending 'POST' request to URL : " + url);
    System.out.println("Post parameters : " + postRequest.getEntity());
    System.out.println("Response Code : " + 
                                response.getStatusLine().getStatusCode());

    BufferedReader rd = new BufferedReader(
                    new InputStreamReader(response.getEntity().getContent()));

    StringBuffer result = new StringBuffer();
    String line = "";
    while ((line = rd.readLine()) != null) {
        result.append(line);
    }

    System.out.println(result.toString());
	
}
	
	public static void main(String[] args) throws IOException, InterruptedException {
		DebugTest eu = new DebugTest();
		eu.sendXMLPost();
		
		//eu.searchAndOpenFile(""); 3370284790
	}

}
