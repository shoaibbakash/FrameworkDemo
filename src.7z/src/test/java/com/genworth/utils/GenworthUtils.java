package com.genworth.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.tavant.base.DriverFactory;
import com.tavant.base.WebPage;
import com.tavant.utils.TwfException;

public class GenworthUtils extends WebPage {
	private static final Logger logger = Logger.getLogger(GenworthUtils.class);
	WebDriver driver =null;
	public void clearAndTypeUI(WebElement element,String value) throws InterruptedException
	{
		logger.debug("Inside clearAndType");
		element.clear();
		Thread.currentThread().sleep(2000);
		//element.click();
		element.sendKeys(value+Keys.TAB);
		Thread.currentThread().sleep(1000);
		logger.debug("Finished clearAndType");
	}

	
	public void clearAndTypeDate(WebElement element,String value) throws InterruptedException
	{
		logger.debug("Inside clearAndTypeDate");
		element.clear();
		Thread.currentThread().sleep(1000);
		element.click();
		Thread.currentThread().sleep(1000);
		element.sendKeys(Keys.BACK_SPACE);
		Thread.currentThread().sleep(1000);
		element.sendKeys(Keys.BACK_SPACE);
		Thread.currentThread().sleep(1000);
		
		element.sendKeys(value+Keys.TAB);
		Thread.currentThread().sleep(1000);
		logger.debug("Finished clearAndTypeDate");
	}
	
	public void waitforLoading(String nothing) throws TwfException, InterruptedException {
		logger.debug("Waiting for Page Load");
		
		WebElement spinner = null;
		try {
			Thread.currentThread().sleep(1000);
		 driver = DriverFactory.getDriver();
		 driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		spinner = driver.findElement(By.xpath(".//div[@class='loading-screen-wrapper']"));
		Thread.currentThread().sleep(1500);
		logger.debug(" Waiting for Page Load with Elements current display status " + spinner.getCssValue("display"));
		WebDriverWait wait = new WebDriverWait(driver, 150);//changed from 100
			wait.until(ExpectedConditions.invisibilityOf(spinner));
			Thread.currentThread().sleep(1000);
		} 
		catch (Exception e) 
		{
			logger.debug("Loading icon not found");
		}
		logger.debug("End of Waiting for Page Load");
	}
	
	
	public void launchChrome(String dummy) throws FileNotFoundException, IOException, InterruptedException
	{
		logger.debug("Inside launchChrome");
	
		Properties prop = new Properties();
		prop.load(new FileInputStream("src/test/resources/user.properties"));
		
		File file = new File("D:\\GenworthLatest\\GenworthCancellationAutomation\\ext\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
		WebDriver driver = new ChromeDriver();
		
		driver.get(prop.getProperty("cancellationURL"));
		driver.manage().window().maximize();
		Thread.currentThread().sleep(1000);
		
		
		logger.debug("Finished launchChrome");
	}
	
	
	public void clearAndType(WebElement element,String value) throws InterruptedException
	{
		logger.debug("Inside clearAndType");
		element.clear();
		Thread.currentThread().sleep(500);
		element.click();
		Thread.currentThread().sleep(500);
		element.sendKeys(value+Keys.TAB);
		Thread.currentThread().sleep(500);
		logger.debug("Finished clearAndType");
	}
	
	@Override
	public void checkPage() {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
